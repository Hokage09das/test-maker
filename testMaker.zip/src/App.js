import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import MainLayout from "./layout/MainLayout";
import Questions from "./components/navigate/Questions";
import TestMaker from "./components/navigate/TestMaker";
import SingleQuestion from "./components/navigate/SingleQuestion";

function App() {
  return (
    <BrowserRouter>
      <div className='App'>
        <Routes>
          <Route
            path='/'
            element={<MainLayout />}
          >
            <Route
              index
              element={<TestMaker />}
            />
            <Route
              path='question'
              element={<Questions />}
            />
            <Route
              path='question/:id'
              element={<SingleQuestion />}
            />
          </Route>
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
